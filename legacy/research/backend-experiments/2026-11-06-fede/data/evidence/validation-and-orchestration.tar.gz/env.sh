export RESEARCH_ROOT=/tmp/spawned-fede-research-25dGGmPA
export PATH=/nix/store/5gk010lr12bwp64cm9rj3pj21c0hviw8-rustc-1.93.0/bin:$PATH
export RUSTC=/nix/store/5gk010lr12bwp64cm9rj3pj21c0hviw8-rustc-1.93.0/bin/rustc
export RUSTDOC=/nix/store/5gk010lr12bwp64cm9rj3pj21c0hviw8-rustc-1.93.0/bin/rustdoc
export CARGO_TARGET_DIR=$RESEARCH_ROOT/target
export CARGO_BUILD_JOBS=4
export CARGO_PROFILE_BENCH_DEBUG=1
export LC_ALL=C LANG=C
export PKG_CONFIG=/nix/store/j5fz28pic24azmxkv183hk6fchfs7ag8-pkg-config-0.29.2/bin/pkg-config
export PKG_CONFIG_PATH=/nix/store/1p14m1hrdkykyxs0l6wg7y29ahppcnsr-openssl-3.6.1-dev/lib/pkgconfig
export LD_LIBRARY_PATH=/nix/store/p96a7p297gmia8zcy4i72qd45wzw8lh6-openssl-3.6.1/lib:${LD_LIBRARY_PATH-}
unset RUSTFLAGS RUSTC_WRAPPER RUSTDOCFLAGS SPAWNED_PROFILE_PREFIX SPAWNED_EXPERIMENT_SCHEDULER SPAWNED_EXPERIMENT_RUNTIME SPAWNED_EXPERIMENT_WORKERS SPAWNED_EXPERIMENT_BATCH TOKIO_WORKER_THREADS
