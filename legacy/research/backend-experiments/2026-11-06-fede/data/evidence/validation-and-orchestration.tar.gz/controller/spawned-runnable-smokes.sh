#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
source "$ROOT/env.sh"
cd "$ROOT/runnable-source"
test "$(git rev-parse HEAD)" = 9a6971155aeb8efa83b484d7459e6d7488c84aea
test -z "$(git status --porcelain)"
test "$(cat "$ROOT/analysis-slot-4/runnable-state")" = complete
export CARGO_TARGET_DIR="$ROOT/runnable-target"
mkdir -p "$ROOT/runnable-v4"
printf 'smoke\n' > "$ROOT/runnable-v4/run-state"
taskset -c 2,3,4,5 python3 benchmarks/fede_runnable.py --stage smoke --stop-at 1793975400 --output "$ROOT/runnable-v4/smoke-2" > "$ROOT/runnable-v4/smoke.log" 2>&1
printf 'scale-smoke\n' > "$ROOT/runnable-v4/run-state"
taskset -c 2,3,4,5,6,7,8,9 python3 benchmarks/fede_runnable.py --stage scale-smoke --stop-at 1793975400 --output "$ROOT/runnable-v4/scale-smoke-2" > "$ROOT/runnable-v4/scale-smoke.log" 2>&1
printf 'soak-smoke\n' > "$ROOT/runnable-v4/run-state"
taskset -c 2,3,4,5 python3 benchmarks/fede_soak.py --runnable-only --smoke --seconds 3 --stop-at 1793975400 --output "$ROOT/runnable-v4/soak-smoke-1" > "$ROOT/runnable-v4/soak-smoke.log" 2>&1
printf 'smokes-complete-waiting-v3\n' > "$ROOT/runnable-v4/run-state"
printf '9a6971155aeb8efa83b484d7459e6d7488c84aea gates + 136/96/2 smoke complete\n' > "$ROOT/runnable-v4/MEASUREMENT-APPROVED"
kill -CONT 1087975
printf 'V3 coordinator1087975 resumed after analysis-slot-4 completed gates and V4 smokes.\n' >> "$ROOT/amortized-v3/analysis-pause.txt"

