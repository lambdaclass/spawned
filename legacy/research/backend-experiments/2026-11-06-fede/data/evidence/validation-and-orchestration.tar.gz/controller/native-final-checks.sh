#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
source "$ROOT/env.sh"
cd "$ROOT/native-final-source"
test "$(git rev-parse HEAD)" = e571b311b280f84eb8c20940a952070dcf1e5664
test -z "$(git status --porcelain)"
export CARGO_TARGET_DIR="$ROOT/native-final-target" CARGO_BUILD_JOBS=4
printf 'native-checks\n' > "$ROOT/analysis-slot-4/native-state"
timeout 600s cargo test --locked --workspace --all-features > "$ROOT/analysis-slot-4/native-workspace.log" 2>&1
SPAWNED_EXPERIMENT_SCHEDULER=native-steal SPAWNED_EXPERIMENT_WORKERS=2 SPAWNED_EXPERIMENT_BATCH=16 timeout 300s cargo test --locked -p spawned-concurrency --all-features -- --test-threads=1 --skip badly_behaved_thread_non_blocking > "$ROOT/analysis-slot-4/native-steal-actors.log" 2>&1
git rev-parse HEAD > "$ROOT/analysis-slot-4/native-checked-source.txt"
printf 'complete\n' > "$ROOT/analysis-slot-4/native-state"

