#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
source "$ROOT/env.sh"
trap 'printf "failed\n" > "$ROOT/controller/early-state"' ERR
printf 'callback-smokes\n' > "$ROOT/controller/early-state"
cd "$ROOT/callback-source"
export CARGO_TARGET_DIR="$ROOT/callback-target"
mkdir -p "$ROOT/callback-v6"
test "$(git rev-parse HEAD)" = 0f81b5769e041c2dd03a63c5d3337636b8949239
test -z "$(git status --porcelain)"
taskset -c 2,3,4,5 python3 benchmarks/fede_zero_schedule.py --stage smoke --stop-at 1793975400 --output "$ROOT/callback-v6/smoke-1" > "$ROOT/callback-v6/smoke.log" 2>&1
printf 'gates +48smokes complete, source0f81b5769e041c2dd03a63c5d3337636b8949239\n' > "$ROOT/callback-v6/MEASUREMENT-APPROVED"
printf 'v4-profiles\n' > "$ROOT/controller/early-state"
cd "$ROOT/runnable-source"
export CARGO_TARGET_DIR="$ROOT/runnable-target"
taskset -c 2,3,4,5 python3 benchmarks/fede_runnable.py --stage profiles --stop-at 1793975400 --output "$ROOT/runnable-v4/profiles-1" > "$ROOT/runnable-v4/profiles.log" 2>&1
printf 'waiting-v3\n' > "$ROOT/runnable-v4/run-state"
printf 'v5-graphs\n' > "$ROOT/controller/early-state"
cd "$ROOT/deque-source"
export CARGO_TARGET_DIR="$ROOT/deque-target"
for phase in graphs profiles; do
 printf 'early-%s\n' "$phase" > "$ROOT/deque-v5/run-state"
 taskset -c 2,3,4,5 python3 benchmarks/fede_deque.py --stage "$phase" --stop-at 1793975400 --output "$ROOT/deque-v5/$phase-1" > "$ROOT/deque-v5/$phase.log" 2>&1
done
printf 'waiting-v4-tail\n' > "$ROOT/deque-v5/run-state"
printf 'v6-graphs\n' > "$ROOT/controller/early-state"
cd "$ROOT/callback-source"
export CARGO_TARGET_DIR="$ROOT/callback-target"
for phase in graphs profiles; do
 printf '%s\n' "$phase" > "$ROOT/callback-v6/run-state"
 taskset -c 2,3,4,5 python3 benchmarks/fede_zero_schedule.py --stage "$phase" --stop-at 1793975400 --output "$ROOT/callback-v6/$phase-1" > "$ROOT/callback-v6/$phase.log" 2>&1
done
printf 'complete\n' > "$ROOT/callback-v6/run-state"
printf 'complete\n' > "$ROOT/controller/early-state"

