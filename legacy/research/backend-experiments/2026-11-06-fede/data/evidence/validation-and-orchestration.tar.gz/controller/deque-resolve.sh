#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
while ! python3 - "$ROOT" <<'PY'
import json,sys,pathlib
r=pathlib.Path(sys.argv[1])
assert '\nState:\tT' in pathlib.Path('/proc/1087975/status').read_text()
if not json.loads((r/'amortized-v3/clock-1/metadata.json').read_text()).get('finished_utc'):sys.exit(1)
for f in pathlib.Path('/proc').glob('[0-9]*/exe'):
 try:x=f.resolve()
 except OSError:continue
 assert not (str(x).startswith(str(r)) and x.name.startswith(('workload_research-','lifecycle_soak-'))),x
PY
do sleep 15; done
source "$ROOT/env.sh"
mkdir -p "$ROOT/analysis-slot-5"
printf 'resolving-deque\n' > "$ROOT/analysis-slot-5/state"
cd "$ROOT/deque-source"
if ! timeout 180s cargo metadata --offline --all-features --format-version 1 > "$ROOT/analysis-slot-5/metadata.json" 2> "$ROOT/analysis-slot-5/resolve-offline.log"; then
 timeout 180s cargo metadata --all-features --format-version 1 > "$ROOT/analysis-slot-5/metadata.json" 2> "$ROOT/analysis-slot-5/resolve-online.log"
fi
printf 'lock-ready\n' > "$ROOT/analysis-slot-5/state"

