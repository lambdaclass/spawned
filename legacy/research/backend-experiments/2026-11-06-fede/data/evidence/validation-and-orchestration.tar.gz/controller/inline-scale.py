#!/usr/bin/env python3
"""Immutable-source eight-core representation follow-up, archived outer controller."""
import argparse
import hashlib
from pathlib import Path
import random
import sys
import time


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--stage',choices=['smoke','scale'],required=True)
    p.add_argument('--stop-at',type=float,required=True)
    a=p.parse_args();sys.path.insert(0,str(a.source/'benchmarks'))
    from fede_research import Campaign,VARIANTS
    VARIANTS.update({v:(v,16) for v in ['native-root','native-runnable','native-deque']})
    a.actor_cpus='2,3,4,5,6,7,8,9';a.driver_cpus='10,11,12,13';a.collector_cpus='14,15,16,17'
    a.seed=223;a.duration=2.;a.timeout=120.;a.smoke=a.stage=='smoke';a.workers=[7,8,9];a.variants=['async','native-root','native-runnable','native-deque']
    c=Campaign(a);assert c.meta['revision']=='acd37a3b7cfc01bf8a0b656a30843c14db0859fd' and not c.meta['dirty']
    c.meta['controller_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    c.meta['purpose']='Outercontrollernewsourceunchangedacd37. Eightphysicalactorcores2..9span96/32MiBL3domains. 16128actors1024logicalproducersfourdriverRTs,two-millionroots. Pairedboxed/inlineTaskDeque atZ1W1,RootW1andTokio8/9controls,DequeN7+R1equalruntimeworkercontrol. No sourcepoolingorhomogeneousstrongscalingclaim. Threefreshreps;profileexcluded.'
    specs=[('async',8,0,0,0),('async',9,0,0,0),('native-root',8,0,0,1)]
    specs += [(v,8,i,1,1) for v in ['native-runnable','native-deque'] for i in [0,1]]
    specs += [('native-deque',7,1,1,1)]
    jobs=[]
    for v,w,i,z,precheck in specs:
        for topology in ['chain','fanout']:
            for layout in ['same','cross']:
                for repeat in range(1 if a.smoke else 3):
                    cfg=dict(mode='graph',topology=topology,layout=layout,actors=16128,width=8,producers=1024,messages=4096 if a.smoke else 2_097_152,iterations=100,caller='async',**{'caller-threads':4,'observation-counter':'on'})
                    exp=dict(SPAWNED_EXPERIMENT_SLICE_US=50,SPAWNED_EXPERIMENT_REACTORS=1,SPAWNED_EXPERIMENT_LOCAL_BUDGET=3,SPAWNED_EXPERIMENT_ROOT_QUANTUM=8,SPAWNED_EXPERIMENT_ZERO_SCHEDULE=z,SPAWNED_EXPERIMENT_WAKE_PRECHECK=precheck,SPAWNED_EXPERIMENT_INLINE_FUTURE=i)
                    jobs.append((v,w,cfg,repeat,exp))
    random.Random(a.seed).shuffle(jobs);c.meta['planned_samples']=len(jobs);c.save()
    for v,w,cfg,repeat,exp in jobs:
        if time.time()>=a.stop_at:c.meta['stopped_at_deadline']=True;break
        row=c.sample('inline-scale-smoke' if a.smoke else 'inline-scale',v,w,cfg,repeat,experiment=exp)
        row['actor_workers']=w;row['total_runtime_workers']=w+(1 if v.startswith('native') else 0);c.save()
    c.meta['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());c.save()


if __name__=='__main__':main()
