#!/usr/bin/env bash
set -euo pipefail
source /tmp/spawned-fede-research-25dGGmPA/env.sh
export CARGO_TARGET_DIR="$RESEARCH_ROOT/amortized-target"
OUTPUT="$RESEARCH_ROOT/amortized"
mkdir -p "$OUTPUT"
cd "$RESEARCH_ROOT/amortized-source"
trap 'echo failed > "$OUTPUT/run-state"' ERR
test -z "$(git status --porcelain)"
git rev-parse HEAD > "$OUTPUT/measured-source.txt"
echo build > "$OUTPUT/run-state"
cargo bench --locked -p spawned-concurrency --features backend-experiments,profiling-experiments --bench workload_research --bench designs --no-run > "$OUTPUT/build.log" 2>&1
echo waiting-analysis > "$OUTPUT/run-state"
while ! test -f "$OUTPUT/ANALYSIS-COMPLETE"; do sleep 5; done
for stage in smoke graphs profiles; do
 echo "$stage" > "$OUTPUT/run-state"
 python3 benchmarks/fede_root.py --stage "$stage" --output "$OUTPUT/$stage-1" --stop-at 1793975400 > "$OUTPUT/$stage-1.log" 2>&1
done
echo complete > "$OUTPUT/run-state"
