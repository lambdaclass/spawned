#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
while ! python3 - "$ROOT" <<'PY'
import pathlib,json,sys
r=pathlib.Path(sys.argv[1])
assert '\nState:\tT' in pathlib.Path('/proc/1087975/status').read_text()
assert '\nState:\tT' in pathlib.Path('/proc/1748742/status').read_text()
if not json.loads((r/'runnable-v4/graphs-1/metadata.json').read_text()).get('finished_utc'):sys.exit(1)
for f in pathlib.Path('/proc').glob('[0-9]*/exe'):
 try:x=f.resolve()
 except OSError:continue
 assert not (str(x).startswith(str(r)) and x.name.startswith(('workload_research-','lifecycle_soak-'))),x
PY
do sleep 15; done
source "$ROOT/env.sh"
mkdir -p "$ROOT/analysis-slot-6"
cd "$ROOT/callback-source"
git fetch https://github.com/lambdaclass/spawned.git perf/fede-zero-schedule > "$ROOT/analysis-slot-6/callback-fetch.log" 2>&1
git reset --hard 0f81b5769e041c2dd03a63c5d3337636b8949239 >> "$ROOT/analysis-slot-6/callback-fetch.log"
test -z "$(git status --porcelain)"
export CARGO_TARGET_DIR="$ROOT/callback-target" CARGO_BUILD_JOBS=4
printf 'unit\n' > "$ROOT/analysis-slot-6/callback-state"
timeout 600s cargo test --locked -p spawned-rt --features backend-experiments --lib experimental::dispatcher::tests -- --test-threads=1 > "$ROOT/analysis-slot-6/callback-unit.log" 2>&1
printf 'actors\n' > "$ROOT/analysis-slot-6/callback-state"
for policy in native-root native-runnable native-deque; do
 SPAWNED_EXPERIMENT_SCHEDULER="$policy" SPAWNED_EXPERIMENT_WORKERS=2 SPAWNED_EXPERIMENT_BATCH=16 SPAWNED_EXPERIMENT_ZERO_SCHEDULE=1 SPAWNED_EXPERIMENT_WAKE_PRECHECK=1 timeout 300s cargo test --locked -p spawned-concurrency --all-features -- --test-threads=1 --skip badly_behaved_thread_non_blocking > "$ROOT/analysis-slot-6/callback-$policy-actors.log" 2>&1
done
printf 'workspace\n' > "$ROOT/analysis-slot-6/callback-state"
timeout 600s cargo test --locked --workspace --all-features > "$ROOT/analysis-slot-6/callback-workspace.log" 2>&1
printf 'release\n' > "$ROOT/analysis-slot-6/callback-state"
timeout 600s cargo bench --locked -p spawned-concurrency --features backend-experiments,profiling-experiments --bench workload_research --bench designs --bench lifecycle_soak --no-run > "$ROOT/analysis-slot-6/callback-build.log" 2>&1
git rev-parse HEAD > "$ROOT/analysis-slot-6/callback-checked-source.txt"
printf 'clippy\n' > "$ROOT/analysis-slot-6/callback-state"
export CARGO_TARGET_DIR="$ROOT/callback-clippy"
export RUSTC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustc
export RUSTDOC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustdoc
timeout 600s cargo clippy --locked --workspace --all-targets --all-features -- -D warnings > "$ROOT/analysis-slot-6/callback-clippy.log" 2>&1
printf 'complete\n' > "$ROOT/analysis-slot-6/callback-state"

