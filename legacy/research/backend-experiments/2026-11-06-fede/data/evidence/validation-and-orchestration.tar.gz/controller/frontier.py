#!/usr/bin/env python3
"""Source-frozen Z/W factorial under offered load, plus paired resource windows."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import subprocess
import sys
import time

SOURCE = Path('/tmp/spawned-fede-research-25dGGmPA/inline-source')
REVISION = 'acd37a3b7cfc01bf8a0b656a30843c14db0859fd'
sys.path.insert(0, str(SOURCE / 'benchmarks'))
from fede_research import Campaign, VARIANTS, SELECTORS, capture, process, write_rows
VARIANTS.update({v:(v,16) for v in ['native-root','native-runnable','native-deque']})
HASH = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
# All pairs fixed before looking at any new offered/resource result. I0 in all cases.
SPECS = [('async',0,0)] + [('native-root',0,w) for w in [0,1]] + [
    (v,z,w) for v in ['native-runnable','native-deque'] for z in [0,1] for w in [0,1]]
RESOURCE = [('async',0,0)] + [(v,m,m) for v in ['native-runnable','native-deque'] for m in [0,1]]


def experiment(z,w):
    return dict(SPAWNED_EXPERIMENT_REACTORS=1, SPAWNED_EXPERIMENT_LOCAL_BUDGET=3,
                SPAWNED_EXPERIMENT_ROOT_QUANTUM=8, SPAWNED_EXPERIMENT_SLICE_US=50,
                SPAWNED_EXPERIMENT_ZERO_SCHEDULE=z, SPAWNED_EXPERIMENT_WAKE_PRECHECK=w,
                SPAWNED_EXPERIMENT_INLINE_FUTURE=0)


def offered(a):
    a.seed=9173;a.duration=2.;a.timeout=120.;a.smoke=a.stage=='smoke'
    a.actor_cpus='2,3,4,5';a.driver_cpus='6,7,14,15';a.collector_cpus='8,9,16,17'
    a.workers=[4];a.variants=[v for v,_,_ in SPECS]
    c=Campaign(a);assert not c.meta['dirty'] and c.meta['revision']==REVISION
    c.meta.update(controller_sha256=HASH,purpose='Source-frozen V7 boxed I0. Complete Z/W factorial for Runnable/Deque, Root W0/1 and Tokio4 reference. Tests graph optimization under mixed offered load; does not promote a backend. Common fixed rates500k/1.2M, spread/concentrated, steady/burst1000, two repeats. Strict original driver-valid threshold and full admitted-work drain retained. Root/Task/Deque all native N4+R1+idle owner on four actor cores.')
    jobs=[]
    for v,z,w in SPECS:
        for layout in ['spread','concentrated']:
            for rate in ([1000] if a.smoke else [500_000,1_200_000]):
                for burst in [1,1000]:
                    for repeat in range(1 if a.smoke else 2):
                        cfg=dict(mode='offered',layout=layout,actors=240,producers=4,
                                 messages=2000 if a.smoke else rate*2,rate=rate,burst=burst,
                                 iterations=100,**{'hot-iterations':5000})
                        jobs.append((v,z,w,cfg,repeat))
    random.Random(a.seed).shuffle(jobs);c.meta['planned_samples']=len(jobs);c.save()
    assert len(jobs)==(44 if a.smoke else 176)
    for v,z,w,cfg,repeat in jobs:
        if time.time()+120>=a.stop_at:c.meta['stopped_at_deadline']=True;break
        row=c.sample('frontier-smoke' if a.smoke else 'frontier-offered',v,4,cfg,repeat,experiment=experiment(z,w))
        row['actor_workers']=4;row['total_runtime_workers']=4+(v!='async');c.save()
    c.meta['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());c.save()


def resources(a):
    seconds=2 if a.stage=='soak-smoke' else 300
    out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
    for sub in ['series','logs']:(out/sub).mkdir()
    assert os.sched_getaffinity(0)=={2,3,4,5}
    meta=dict(started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),revision=capture('git','rev-parse','HEAD'),dirty=bool(capture('git','status','--porcelain')),rustc=capture('rustc','--version'),cargo=capture('cargo','--version'),cpu=capture('lscpu'),load_before=Path('/proc/loadavg').read_text(),actor_cpus='2,3,4,5',driver_cpus='6,7,14,15',sampler_cpus='8,9,16,17',nice=os.nice(0),seconds=seconds,smoke=a.stage=='soak-smoke',controller_sha256=HASH,planned_samples=5,schedule=[],environment={k:os.environ.get(k) for k in ['RUSTFLAGS','CARGO_PROFILE_BENCH_DEBUG','CARGO_BUILD_JOBS']},purpose='Five source-matched I0 resource cases: Tokio4, Runnable/Deque baseline Z0W0 versus joint Z1W1; five-minute windows fixed before resource outcomes. Histories bounded, no actor-memory isolation or leak-proof claim. Driver/CPU affinity unchanged. Inline I1 not carried forward on throughput evidence.')
    assert not meta['dirty'] and meta['revision']==REVISION
    result=subprocess.run(['cargo','bench','--locked','-p','spawned-concurrency','--features','backend-experiments,profiling-experiments','--bench','lifecycle_soak','--no-run','--message-format=json'],cwd=SOURCE,capture_output=True,text=True)
    (out/'build.log').write_text(result.stderr);result.check_returncode()
    artifacts=[json.loads(line) for line in result.stdout.splitlines()]
    executable=next(x['executable'] for x in artifacts if x.get('reason')=='compiler-artifact' and x['target']['name']=='lifecycle_soak' and 'bench' in x['target']['kind'] and x.get('executable'))
    meta['binary_sha256']=hashlib.sha256(Path(executable).read_bytes()).hexdigest()
    specs=list(RESOURCE);random.Random(9174).shuffle(specs);records=[]
    def save():
        (out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
        if records:write_rows(out/'raw.csv',records)
    save()
    for v,z,w in specs:
        if time.time()+seconds+60>a.stop_at:meta['stopped_at_deadline']=True;break
        stem=f'{len(records):02d}-{v}-z{z}w{w}';env=dict(os.environ,LC_ALL='C')
        for key in SELECTORS:env.pop(key,None)
        if v!='async':env.update(SPAWNED_EXPERIMENT_SCHEDULER=v,SPAWNED_EXPERIMENT_WORKERS='4',SPAWNED_EXPERIMENT_BATCH='16')
        exp=experiment(z,w);env.update({k:str(v) for k,v in exp.items()})
        config=dict(seconds=seconds,workers=4,idle=32 if meta['smoke'] else 1024,churn=16 if meta['smoke'] else 128,steps=4 if meta['smoke'] else 16,series=str(out/'series'/f'{stem}.csv'),**{'driver-cpus':meta['driver_cpus'],'sampler-cpus':meta['sampler_cpus']})
        meta['schedule'].append(dict(variant=v,actor_workers=4,total_runtime_workers=4+(v!='async'),experiment=exp,config=config));save();start=time.monotonic()
        status,stdout,stderr=process(['taskset','-c',meta['actor_cpus'],'/usr/bin/time','-v',executable]+[f'--{k}={v}' for k,v in config.items()],env,out/'logs'/stem,seconds+60)
        row=dict(variant=v,workers=4,actor_workers=4,total_runtime_workers=4+(v!='async'),status=status,stem=stem,wall_s=time.monotonic()-start,config_json=json.dumps(config,sort_keys=True),experiment_json=json.dumps(exp,sort_keys=True))
        if status=='ok':
            parsed=list(csv.DictReader(stdout.splitlines()));assert len(parsed)==1 and None not in parsed[0];row.update(parsed[0])
            assert int(row['started'])==int(row['stopped'])==int(row['dropped']) and int(row['cycles'])>0
        records.append(row);save();print(f'{len(records)} {stem}: {status}',flush=True)
        if status!='ok':raise RuntimeError('Resource outcome failed; preserve and investigate')
    meta['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());save()


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--stage',choices=['smoke','offered','soak-smoke','soaks'],required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--stop-at',type=float,required=True)
    a=p.parse_args();assert capture('git','rev-parse','HEAD')==REVISION and not capture('git','status','--porcelain')
    if a.stage in ['smoke','offered']:offered(a)
    else:resources(a)


if __name__=='__main__':main()
