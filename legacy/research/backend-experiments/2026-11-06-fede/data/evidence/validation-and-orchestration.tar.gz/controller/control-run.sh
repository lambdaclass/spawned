#!/usr/bin/env bash
set -euo pipefail
source /tmp/spawned-fede-research-25dGGmPA/env.sh
export CONTROL_ROOT="$RESEARCH_ROOT/controls"
export CARGO_TARGET_DIR="$CONTROL_ROOT/target"
cd "$CONTROL_ROOT/source"
trap 'echo failed > "$CONTROL_ROOT/run-state"' ERR
test -z "$(git status --porcelain)"
git rev-parse HEAD > "$CONTROL_ROOT/measured-source.txt"
echo build > "$CONTROL_ROOT/run-state"
cargo bench --locked -p spawned-concurrency --features backend-experiments,profiling-experiments --bench workload_research --bench designs --bench lifecycle_soak --no-run --message-format=json > "$CONTROL_ROOT/final-artifacts.jsonl" 2> "$CONTROL_ROOT/final-build.log"
export SPAWNED_RESEARCH_BINARY=$(python3 -c 'import json;print(next(x["executable"] for x in map(json.loads,open("/tmp/spawned-fede-research-25dGGmPA/controls/final-artifacts.jsonl")) if x.get("reason")=="compiler-artifact" and x["target"]["name"]=="workload_research" and x.get("executable")))')
echo behavior > "$CONTROL_ROOT/run-state"
python3 -m unittest discover -s benchmarks -p test_research_driver.py > "$CONTROL_ROOT/final-behavior.log" 2>&1
echo smoke > "$CONTROL_ROOT/run-state"
python3 benchmarks/fede_controls.py --stage smoke --output "$CONTROL_ROOT/smoke-1" --stop-at 1793975400 > "$CONTROL_ROOT/smoke-1.log" 2>&1
python3 benchmarks/fede_soak.py --seconds 3 --smoke --output "$CONTROL_ROOT/soak-smoke-1" --stop-at 1793975400 > "$CONTROL_ROOT/soak-smoke-1.log" 2>&1
echo waiting-review > "$CONTROL_ROOT/run-state"
while ! test -f "$CONTROL_ROOT/MEASUREMENT-APPROVED"; do sleep 10; done
for stage in profiles queues callers clock offered; do
 echo "$stage" > "$CONTROL_ROOT/run-state"
 python3 benchmarks/fede_controls.py --stage "$stage" --output "$CONTROL_ROOT/$stage-1" --stop-at 1793975400 > "$CONTROL_ROOT/$stage-1.log" 2>&1
done
echo soaks > "$CONTROL_ROOT/run-state"
python3 benchmarks/fede_soak.py --seconds 600 --output "$CONTROL_ROOT/soaks-1" --stop-at 1793975400 > "$CONTROL_ROOT/soaks-1.log" 2>&1
echo complete > "$CONTROL_ROOT/run-state"
