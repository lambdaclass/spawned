#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
while true; do
 state=$(cat "$ROOT/runnable-v4/run-state")
 if test "$state" = complete; then break; fi
 if test "$state" = failed; then exit 1; fi
 if test "$(date +%s)" -ge 1793975400; then printf 'deadline-before-tail\n' > "$ROOT/deque-v5/run-state"; exit 0; fi
 sleep 15
done
source "$ROOT/env.sh"
cd "$ROOT/deque-source"
export CARGO_TARGET_DIR="$ROOT/deque-target"
test "$(git rev-parse HEAD)" = 329006e8c02e7c4b2711d035ac2f942454c2e723
test -z "$(git status --porcelain)"
trap 'printf "failed\n" > "$ROOT/deque-v5/run-state"' ERR
for stage in scale offered; do
 printf '%s\n' "$stage" > "$ROOT/deque-v5/run-state"
 cpus=2,3,4,5; if test "$stage" = scale; then cpus=2,3,4,5,6,7,8,9; fi
 taskset -c "$cpus" python3 benchmarks/fede_deque.py --stage "$stage" --stop-at 1793975400 --output "$ROOT/deque-v5/$stage-1" > "$ROOT/deque-v5/$stage.log" 2>&1
done
printf 'soaks\n' > "$ROOT/deque-v5/run-state"
taskset -c 2,3,4,5 python3 benchmarks/fede_soak.py --deque-only --seconds 300 --stop-at 1793975400 --output "$ROOT/deque-v5/soaks-1" > "$ROOT/deque-v5/soaks.log" 2>&1
python3 - "$ROOT/deque-v5" <<'PY'
import json,pathlib,sys,csv
r=pathlib.Path(sys.argv[1]);ok=True
for stage,expected in [('graphs',560),('profiles',16),('scale',84),('offered',80),('soaks',2)]:
 p=r/(stage+'-1');m=json.loads((p/'metadata.json').read_text());n=len(list(csv.DictReader((p/'raw.csv').open()))) if (p/'raw.csv').exists() else 0
 ok &= bool(m.get('finished_utc')) and not m.get('stopped_at_deadline') and n==expected
(r/'run-state').write_text('complete\n' if ok else 'deadline-partial\n')
PY

