#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
mkdir -p "$ROOT/analysis-slot-9"
trap 'printf "failed\n" > "$ROOT/analysis-slot-9/fairness-state"' ERR
python3 - "$ROOT" <<'PY'
import pathlib,sys
r=pathlib.Path(sys.argv[1])
for f in pathlib.Path('/proc').glob('[0-9]*/exe'):
 try:x=f.resolve()
 except OSError:continue
 assert not (str(x).startswith(str(r)) and x.name.startswith(('workload_research-','lifecycle_soak-'))),x
PY
source "$ROOT/env.sh"
git -C "$ROOT/source" fetch https://github.com/lambdaclass/spawned.git perf/fede-owner-deque-review > "$ROOT/analysis-slot-9/fairness-fetch.log" 2>&1
git -C "$ROOT/source" fetch https://github.com/lambdaclass/spawned.git research/fede-deque-starvation-red >> "$ROOT/analysis-slot-9/fairness-fetch.log" 2>&1
git -C "$ROOT/fairness-source" checkout --detach 95b4ca6d081e8bed912affb928ec3c2694f50ab1 >> "$ROOT/analysis-slot-9/fairness-fetch.log" 2>&1
cd "$ROOT/fairness-source"
export CARGO_TARGET_DIR="$ROOT/fairness-target" CARGO_BUILD_JOBS=4
printf 'red-regression\n' > "$ROOT/analysis-slot-9/fairness-state"
set +e
timeout 600s cargo test --locked -p spawned-rt --features backend-experiments --lib oldest_local_progress_under_sustained_injection -- --test-threads=1 > "$ROOT/analysis-slot-9/fairness-before.log" 2>&1
result=$?
set -e
test "$result" -eq 101
rg 'old local ticket starved behind sustained injection' "$ROOT/analysis-slot-9/fairness-before.log"
git checkout --detach e633e590a7cd286b1b15e47153995b6787c5d396 >> "$ROOT/analysis-slot-9/fairness-fetch.log" 2>&1
test -z "$(git status --porcelain)"
printf 'unit\n' > "$ROOT/analysis-slot-9/fairness-state"
timeout 600s cargo test --locked -p spawned-rt --features backend-experiments --lib -- --test-threads=1 > "$ROOT/analysis-slot-9/fairness-unit.log" 2>&1
printf 'actors\n' > "$ROOT/analysis-slot-9/fairness-state"
for mode in 0 1; do
 SPAWNED_EXPERIMENT_SCHEDULER=native-deque SPAWNED_EXPERIMENT_WORKERS=4 SPAWNED_EXPERIMENT_BATCH=16 SPAWNED_EXPERIMENT_ZERO_SCHEDULE="$mode" SPAWNED_EXPERIMENT_WAKE_PRECHECK="$mode" timeout 300s cargo test --locked -p spawned-concurrency --all-features -- --test-threads=1 --skip badly_behaved_thread_non_blocking > "$ROOT/analysis-slot-9/fairness-deque-mode$mode-actors.log" 2>&1
done
printf 'workspace\n' > "$ROOT/analysis-slot-9/fairness-state"
timeout 600s cargo test --locked --workspace --all-features > "$ROOT/analysis-slot-9/fairness-workspace.log" 2>&1
printf 'release\n' > "$ROOT/analysis-slot-9/fairness-state"
timeout 600s cargo bench --locked -p spawned-concurrency --features backend-experiments,profiling-experiments --bench workload_research --bench designs --bench lifecycle_soak --no-run > "$ROOT/analysis-slot-9/fairness-build.log" 2>&1
git rev-parse HEAD > "$ROOT/analysis-slot-9/fairness-checked-source.txt"
printf 'clippy\n' > "$ROOT/analysis-slot-9/fairness-state"
export CARGO_TARGET_DIR="$ROOT/fairness-clippy"
export RUSTC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustc
export RUSTDOC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustdoc
timeout 600s cargo clippy --locked --workspace --all-targets --all-features -- -D warnings > "$ROOT/analysis-slot-9/fairness-clippy.log" 2>&1
printf 'complete\n' > "$ROOT/analysis-slot-9/fairness-state"
nohup env -u RUSTC -u RUSTDOC nice -n 10 taskset -c 2,3,4,5 bash "$ROOT/controller/root-rest2.sh" > "$ROOT/controller/root-rest2.log" 2>&1 < /dev/null &
printf 'New continuous resource runner launched PID%s\n' "$!" >> "$ROOT/controller/deque-fairness-analysis-pause.txt"
