#!/usr/bin/env bash
set -euo pipefail
RESEARCH_ROOT=/tmp/spawned-fede-research-25dGGmPA
trap 'echo failed > "$RESEARCH_ROOT/confirmation-state"' ERR
echo waiting-primary > "$RESEARCH_ROOT/confirmation-state"
while true; do
  state=$(cat "$RESEARCH_ROOT/run-state")
  if [[ "$state" == complete ]]; then break; fi
  if [[ "$state" == failed ]]; then echo primary-failed > "$RESEARCH_ROOT/confirmation-state"; exit 1; fi
  sleep 20
done
source "$RESEARCH_ROOT/env.sh"
cd "$RESEARCH_ROOT/source"
echo measuring > "$RESEARCH_ROOT/confirmation-state"
python3 "$RESEARCH_ROOT/controller/fede_confirm.py" --source "$RESEARCH_ROOT/source" --primary "$RESEARCH_ROOT/full-2" --output "$RESEARCH_ROOT/confirmation-1" > "$RESEARCH_ROOT/confirmation-1.log" 2>&1
echo complete > "$RESEARCH_ROOT/confirmation-state"
