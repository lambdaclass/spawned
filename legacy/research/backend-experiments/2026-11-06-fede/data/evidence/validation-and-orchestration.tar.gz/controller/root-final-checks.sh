#!/usr/bin/env bash
set -euo pipefail
source /tmp/spawned-fede-research-25dGGmPA/env.sh
OUT="$RESEARCH_ROOT/analysis-slot-3"
cd "$RESEARCH_ROOT/amortized-source"
export CARGO_TARGET_DIR="$RESEARCH_ROOT/amortized-target"
trap 'echo failed > "$OUT/root-final-state"' ERR
git rev-parse HEAD > "$OUT/root-final-source.txt"
echo unit > "$OUT/root-final-state"
cargo test --locked -p spawned-rt --features backend-experiments --lib dispatcher::tests -- --test-threads=1 > "$OUT/root-final-unit.log" 2>&1
echo actors > "$OUT/root-final-state"
SPAWNED_EXPERIMENT_SCHEDULER=native-root SPAWNED_EXPERIMENT_WORKERS=2 SPAWNED_EXPERIMENT_BATCH=16 cargo test --locked -p spawned-concurrency --all-features -- --test-threads=1 --skip badly_behaved_thread_non_blocking > "$OUT/root-final-actors.log" 2>&1
echo clippy > "$OUT/root-final-state"
RUSTC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustc RUSTDOC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustdoc CARGO_TARGET_DIR="$RESEARCH_ROOT/amortized-clippy" cargo clippy --locked --all-targets --all-features -- -D warnings > "$OUT/root-final-clippy.log" 2>&1
echo complete > "$OUT/root-final-state"
