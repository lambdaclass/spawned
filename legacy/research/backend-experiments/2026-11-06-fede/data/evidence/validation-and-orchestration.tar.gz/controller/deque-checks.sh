#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
source "$ROOT/env.sh"
cd "$ROOT/deque-source"
git fetch https://github.com/lambdaclass/spawned.git perf/fede-deque-dispatch > "$ROOT/analysis-slot-5/deque-fetch.log" 2>&1
git reset --hard 329006e8c02e7c4b2711d035ac2f942454c2e723 >> "$ROOT/analysis-slot-5/deque-fetch.log"
test -z "$(git status --porcelain)"
export CARGO_TARGET_DIR="$ROOT/deque-target" CARGO_BUILD_JOBS=4
printf 'unit\n' > "$ROOT/analysis-slot-5/deque-state"
timeout 600s cargo test --locked -p spawned-rt --features backend-experiments --lib experimental::dispatcher::tests -- --test-threads=1 > "$ROOT/analysis-slot-5/deque-unit.log" 2>&1
printf 'actors\n' > "$ROOT/analysis-slot-5/deque-state"
SPAWNED_EXPERIMENT_SCHEDULER=native-deque SPAWNED_EXPERIMENT_WORKERS=2 SPAWNED_EXPERIMENT_BATCH=16 timeout 300s cargo test --locked -p spawned-concurrency --all-features -- --test-threads=1 --skip badly_behaved_thread_non_blocking > "$ROOT/analysis-slot-5/deque-actors.log" 2>&1
printf 'workspace\n' > "$ROOT/analysis-slot-5/deque-state"
timeout 600s cargo test --locked --workspace --all-features > "$ROOT/analysis-slot-5/deque-workspace.log" 2>&1
printf 'release\n' > "$ROOT/analysis-slot-5/deque-state"
timeout 600s cargo bench --locked -p spawned-concurrency --features backend-experiments,profiling-experiments --bench workload_research --bench designs --bench lifecycle_soak --no-run > "$ROOT/analysis-slot-5/deque-build.log" 2>&1
git rev-parse HEAD > "$ROOT/analysis-slot-5/deque-checked-source.txt"
printf 'clippy\n' > "$ROOT/analysis-slot-5/deque-state"
export CARGO_TARGET_DIR="$ROOT/deque-clippy"
export RUSTC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustc
export RUSTDOC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustdoc
timeout 600s cargo clippy --locked --workspace --all-targets --all-features -- -D warnings > "$ROOT/analysis-slot-5/deque-clippy.log" 2>&1
printf 'complete\n' > "$ROOT/analysis-slot-5/deque-state"

