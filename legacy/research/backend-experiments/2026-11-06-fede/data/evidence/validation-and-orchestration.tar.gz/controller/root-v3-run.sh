#!/usr/bin/env bash
set -euo pipefail
source /tmp/spawned-fede-research-25dGGmPA/env.sh
export CARGO_TARGET_DIR="$RESEARCH_ROOT/amortized-target"
OUTPUT="$RESEARCH_ROOT/amortized-v3"
mkdir -p "$OUTPUT"
cd "$RESEARCH_ROOT/amortized-source"
trap 'echo failed > "$OUTPUT/run-state"' ERR
test -z "$(git status --porcelain)"
git diff --exit-code 42c98bd HEAD -- '*.rs' 'Cargo.toml' 'Cargo.lock'
git rev-parse HEAD > "$OUTPUT/measured-source.txt"
echo build > "$OUTPUT/run-state"
cargo bench --locked -p spawned-concurrency --features backend-experiments,profiling-experiments --bench workload_research --bench designs --bench lifecycle_soak --no-run > "$OUTPUT/build.log" 2>&1
echo waiting-checks > "$OUTPUT/run-state"
until test "$(cat "$RESEARCH_ROOT/analysis-slot-3/stop-checks-state")" = complete; do sleep 5; done
echo smoke > "$OUTPUT/run-state"
python3 benchmarks/fede_root.py --stage smoke --output "$OUTPUT/smoke-1" --stop-at 1793975400 > "$OUTPUT/smoke-1.log" 2>&1
python3 benchmarks/fede_soak.py --seconds 3 --smoke --output "$OUTPUT/soak-smoke-1" --stop-at 1793975400 > "$OUTPUT/soak-smoke-1.log" 2>&1
for stage in graphs profiles; do
 echo "$stage" > "$OUTPUT/run-state"
 python3 benchmarks/fede_root.py --stage "$stage" --output "$OUTPUT/$stage-1" --stop-at 1793975400 > "$OUTPUT/$stage-1.log" 2>&1
done
for stage in clock offered; do
 echo "$stage" > "$OUTPUT/run-state"
 python3 benchmarks/fede_controls.py --stage "$stage" --output "$OUTPUT/$stage-1" --stop-at 1793975400 > "$OUTPUT/$stage-1.log" 2>&1
done
echo soaks > "$OUTPUT/run-state"
python3 benchmarks/fede_soak.py --seconds 600 --output "$OUTPUT/soaks-1" --stop-at 1793975400 > "$OUTPUT/soaks-1.log" 2>&1
echo complete > "$OUTPUT/run-state"
