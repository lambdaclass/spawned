#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
mkdir -p "$ROOT/analysis-slot-12"
trap 'printf "failed\n" > "$ROOT/analysis-slot-12/pinned-state"' ERR
test "$(cat "$ROOT/fairness-v8/run-state")" = complete
test "$(cat "$ROOT/pinned-v9/run-state")" = complete
source "$ROOT/env.sh"
git -C "$ROOT/source" fetch https://github.com/lambdaclass/spawned.git perf/fede-pinned-profile > "$ROOT/analysis-slot-12/fetch.log" 2>&1
git -C "$ROOT/source" worktree add --detach "$ROOT/pinned-retain-source" 20260cd9ff6db9809dc2a22ebd92867aee94490a >> "$ROOT/analysis-slot-12/fetch.log" 2>&1
cd "$ROOT/pinned-retain-source"
test -z "$(git status --porcelain)"
# V8 is finished. Reuse its cache only after every scored process has exited.
python3 - "$ROOT" <<'PY'
from pathlib import Path
import sys
r=Path(sys.argv[1])
for f in Path('/proc').glob('[0-9]*/exe'):
 try:x=f.resolve()
 except OSError:continue
 assert not (str(x).startswith(str(r)) and x.name.startswith(('workload_research-','lifecycle_soak-','designs-','pinned_pipeline-'))),x
PY
export CARGO_TARGET_DIR="$ROOT/fairness-target" CARGO_BUILD_JOBS=4
printf 'unit\n' > "$ROOT/analysis-slot-12/pinned-state"
timeout 600s cargo test --locked -p spawned-rt --features backend-experiments --lib -- --test-threads=1 > "$ROOT/analysis-slot-12/unit.log" 2>&1
printf 'actors\n' > "$ROOT/analysis-slot-12/pinned-state"
for mode in 0 1; do
 SPAWNED_EXPERIMENT_SCHEDULER=sharded SPAWNED_EXPERIMENT_WORKERS=2 SPAWNED_EXPERIMENT_BATCH=16 SPAWNED_EXPERIMENT_PIN_CORES=2,3 SPAWNED_EXPERIMENT_IDLE_SPIN="$mode" timeout 300s cargo test --locked -p spawned-concurrency --all-features -- --test-threads=1 --skip badly_behaved_thread_non_blocking > "$ROOT/analysis-slot-12/shard-mode$mode.log" 2>&1
done
printf 'workspace\n' > "$ROOT/analysis-slot-12/pinned-state"
timeout 600s cargo test --locked --workspace --all-features > "$ROOT/analysis-slot-12/workspace.log" 2>&1
printf 'release\n' > "$ROOT/analysis-slot-12/pinned-state"
timeout 600s cargo bench --locked -p spawned-concurrency --features backend-experiments --bench pinned_pipeline --no-run > "$ROOT/analysis-slot-12/build.log" 2>&1
printf 'clippy\n' > "$ROOT/analysis-slot-12/pinned-state"
export CARGO_TARGET_DIR="$ROOT/fairness-clippy"
export RUSTC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustc
export RUSTDOC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustdoc
timeout 600s cargo clippy --locked --workspace --all-targets --all-features -- -D warnings > "$ROOT/analysis-slot-12/clippy.log" 2>&1
git rev-parse HEAD > "$ROOT/analysis-slot-12/checked-source.txt"
printf 'complete\n' > "$ROOT/analysis-slot-12/pinned-state"
