#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
test "$(cat "$ROOT/analysis-slot-7/inline-state")" = complete
source "$ROOT/env.sh"
cd "$ROOT/inline-source"
export CARGO_TARGET_DIR="$ROOT/inline-target"
test "$(git rev-parse HEAD)" = acd37a3b7cfc01bf8a0b656a30843c14db0859fd
test -z "$(git status --porcelain)"
mkdir -p "$ROOT/inline-v7"
trap 'printf "failed\n" > "$ROOT/inline-v7/run-state"' ERR
printf 'smoke\n' > "$ROOT/inline-v7/run-state"
taskset -c 2,3,4,5 python3 benchmarks/fede_inline.py --stage smoke --stop-at 1793975400 --output "$ROOT/inline-v7/smoke-1" > "$ROOT/inline-v7/smoke.log" 2>&1
printf 'gates +44smokes, sourceacd37a3b7cfc01bf8a0b656a30843c14db0859fd\n' > "$ROOT/inline-v7/MEASUREMENT-APPROVED"
for phase in graphs profiles; do
 printf '%s\n' "$phase" > "$ROOT/inline-v7/run-state"
 taskset -c 2,3,4,5 python3 benchmarks/fede_inline.py --stage "$phase" --stop-at 1793975400 --output "$ROOT/inline-v7/$phase-1" > "$ROOT/inline-v7/$phase.log" 2>&1
done
if test -f "$ROOT/controller/inline-scale.py"; then
 for phase in smoke scale; do
  printf 'scale-%s\n' "$phase" > "$ROOT/inline-v7/run-state"
  taskset -c 2,3,4,5,6,7,8,9 python3 "$ROOT/controller/inline-scale.py" --source "$ROOT/inline-source" --stage "$phase" --stop-at 1793975400 --output "$ROOT/inline-v7/scale-$phase-1" > "$ROOT/inline-v7/scale-$phase.log" 2>&1
 done
fi
printf 'complete\n' > "$ROOT/inline-v7/run-state"
kill -CONT 2282516
printf 'V7gates/pairedgraphsprofiles/(optionaldeclaredscale) complete. Root-rest2282516 resumed for offered432 and300sresourcecases.\n' >> "$ROOT/controller/inline-pause-7.txt"

