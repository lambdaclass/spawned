#!/usr/bin/env bash
set -euo pipefail
source /tmp/spawned-fede-research-25dGGmPA/env.sh
OUTPUT="$RESEARCH_ROOT/analysis-slot-3"
cd "$RESEARCH_ROOT/stop-proof"
export CARGO_TARGET_DIR="$RESEARCH_ROOT/stop-target"
trap 'echo failed > "$OUTPUT/stop-checks-state"' ERR
git rev-parse HEAD > "$OUTPUT/stop-checked-source.txt"
echo regressions > "$OUTPUT/stop-checks-state"
cargo test --locked -p spawned-concurrency --lib idle_stop_regression -- --test-threads=1 > "$OUTPUT/idle-stop-after.log" 2>&1
echo workspace > "$OUTPUT/stop-checks-state"
cargo test --locked --workspace --all-features > "$OUTPUT/stop-workspace.log" 2>&1
echo sharded > "$OUTPUT/stop-checks-state"
SPAWNED_EXPERIMENT_SCHEDULER=sharded SPAWNED_EXPERIMENT_WORKERS=2 SPAWNED_EXPERIMENT_BATCH=0 cargo test --locked -p spawned-concurrency --all-features -- --test-threads=1 --skip badly_behaved_thread_non_blocking > "$OUTPUT/stop-sharded.log" 2>&1
echo clippy > "$OUTPUT/stop-checks-state"
RUSTC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustc RUSTDOC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustdoc CARGO_TARGET_DIR="$RESEARCH_ROOT/stop-clippy" cargo clippy --locked --all-targets --all-features -- -D warnings > "$OUTPUT/stop-clippy.log" 2>&1
echo complete > "$OUTPUT/stop-checks-state"
