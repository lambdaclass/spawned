#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
source "$ROOT/env.sh"
cd "$ROOT/runnable-source"
git fetch https://github.com/lambdaclass/spawned.git perf/fede-runnable-dispatch > "$ROOT/analysis-slot-4/runnable-fetch.log" 2>&1
git reset --hard 9a6971155aeb8efa83b484d7459e6d7488c84aea >> "$ROOT/analysis-slot-4/runnable-fetch.log"
test -z "$(git status --porcelain)"
export CARGO_TARGET_DIR="$ROOT/runnable-target" CARGO_BUILD_JOBS=4
printf 'unit\n' > "$ROOT/analysis-slot-4/runnable-state"
timeout 600s cargo test --locked -p spawned-rt --features backend-experiments --lib experimental::dispatcher::tests -- --test-threads=1 > "$ROOT/analysis-slot-4/runnable-unit.log" 2>&1
printf 'actors\n' > "$ROOT/analysis-slot-4/runnable-state"
SPAWNED_EXPERIMENT_SCHEDULER=native-runnable SPAWNED_EXPERIMENT_WORKERS=2 SPAWNED_EXPERIMENT_BATCH=16 timeout 300s cargo test --locked -p spawned-concurrency --all-features -- --test-threads=1 --skip badly_behaved_thread_non_blocking > "$ROOT/analysis-slot-4/runnable-actors.log" 2>&1
printf 'workspace\n' > "$ROOT/analysis-slot-4/runnable-state"
timeout 600s cargo test --locked --workspace --all-features > "$ROOT/analysis-slot-4/runnable-workspace.log" 2>&1
printf 'release\n' > "$ROOT/analysis-slot-4/runnable-state"
timeout 600s cargo bench --locked -p spawned-concurrency --features backend-experiments,profiling-experiments --bench workload_research --bench designs --bench lifecycle_soak --no-run > "$ROOT/analysis-slot-4/runnable-build.log" 2>&1
git rev-parse HEAD > "$ROOT/analysis-slot-4/runnable-checked-source.txt"
printf 'clippy\n' > "$ROOT/analysis-slot-4/runnable-state"
export CARGO_TARGET_DIR="$ROOT/runnable-clippy"
export RUSTC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustc
export RUSTDOC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustdoc
timeout 600s cargo clippy --locked --workspace --all-targets --all-features -- -D warnings > "$ROOT/analysis-slot-4/runnable-clippy.log" 2>&1
printf 'complete\n' > "$ROOT/analysis-slot-4/runnable-state"

