#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
while test "$(cat "$ROOT/analysis-slot-5/deque-state" 2>/dev/null || true)" != complete; do
 if test "$(date +%s)" -ge 1793975400; then exit 1; fi
 sleep 15
done
test "$(cat "$ROOT/analysis-slot-5/runnable-state")" = complete
test "$(awk '/State:/{print $2}' /proc/1087975/status)" = T
source "$ROOT/env.sh"
trap 'printf "failed\n" > "$ROOT/controller/early-state"' ERR
printf 'v4-smokes\n' > "$ROOT/controller/early-state"
bash "$ROOT/controller/runnable-final-smokes.sh"
printf 'v5-smokes\n' > "$ROOT/controller/early-state"
bash "$ROOT/controller/deque-smokes.sh"
printf 'v4-graphs\n' > "$ROOT/controller/early-state"
cd "$ROOT/runnable-source"
export CARGO_TARGET_DIR="$ROOT/runnable-target"
for stage in graphs profiles; do
 printf 'early-%s\n' "$stage" > "$ROOT/runnable-v4/run-state"
 taskset -c 2,3,4,5 python3 benchmarks/fede_runnable.py --stage "$stage" --stop-at 1793975400 --output "$ROOT/runnable-v4/$stage-1" > "$ROOT/runnable-v4/$stage.log" 2>&1
done
printf 'waiting-v3\n' > "$ROOT/runnable-v4/run-state"
printf 'v5-graphs\n' > "$ROOT/controller/early-state"
cd "$ROOT/deque-source"
export CARGO_TARGET_DIR="$ROOT/deque-target"
for stage in graphs profiles; do
 printf 'early-%s\n' "$stage" > "$ROOT/deque-v5/run-state"
 taskset -c 2,3,4,5 python3 benchmarks/fede_deque.py --stage "$stage" --stop-at 1793975400 --output "$ROOT/deque-v5/$stage-1" > "$ROOT/deque-v5/$stage.log" 2>&1
done
printf 'waiting-v4-tail\n' > "$ROOT/deque-v5/run-state"
kill -CONT 1087975
printf 'Analysis-slot5 + V4/V5 early graph/profile blocks complete; parent1087975 resumed.\n' >> "$ROOT/amortized-v3/analysis-pause-5.txt"
printf 'complete\n' > "$ROOT/controller/early-state"

