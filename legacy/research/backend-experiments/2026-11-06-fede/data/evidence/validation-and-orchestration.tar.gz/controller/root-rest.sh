#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
while test "$(cat "$ROOT/controller/early-state")" != complete; do
 if test "$(cat "$ROOT/controller/early-state")" = failed; then exit 1; fi
 sleep 15
done
source "$ROOT/env.sh"
cd "$ROOT/amortized-source"
export CARGO_TARGET_DIR="$ROOT/amortized-target"
test "$(git rev-parse HEAD)" = 097ae02f6d05e383b303594bfe9fbfbfc9141666
test -z "$(git status --porcelain)"
trap 'printf "failed\n" > "$ROOT/amortized-v3/run-state"' ERR
printf 'offered\n' > "$ROOT/amortized-v3/run-state"
taskset -c 2,3,4,5 python3 benchmarks/fede_controls.py --stage offered --stop-at 1793975400 --output "$ROOT/amortized-v3/offered-1" > "$ROOT/amortized-v3/offered.log" 2>&1
printf 'soaks\n' > "$ROOT/amortized-v3/run-state"
taskset -c 2,3,4,5 python3 benchmarks/fede_soak.py --seconds 300 --stop-at 1793975400 --output "$ROOT/amortized-v3/soaks-1" > "$ROOT/amortized-v3/soaks.log" 2>&1
python3 - "$ROOT/amortized-v3" <<'PY'
import pathlib,json,sys,csv
r=pathlib.Path(sys.argv[1]);ok=True
for phase,count in [('graphs',520),('profiles',24),('clock',340),('offered',432),('soaks',10)]:
 p=r/(phase+'-1');m=json.loads((p/'metadata.json').read_text());n=len(list(csv.DictReader((p/'raw.csv').open()))) if (p/'raw.csv').exists() else 0
 ok &= bool(m.get('finished_utc')) and not m.get('stopped_at_deadline') and n==count
(r/'run-state').write_text('complete\n' if ok else 'deadline-partial\n')
PY

