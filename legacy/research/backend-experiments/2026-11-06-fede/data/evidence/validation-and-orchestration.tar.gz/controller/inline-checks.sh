#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
while ! python3 - "$ROOT" <<'PY'
import pathlib,sys
r=pathlib.Path(sys.argv[1])
assert '\nState:\tT' in pathlib.Path('/proc/2282516/status').read_text()
if (r/'controller/early-state').read_text().strip()!='complete':sys.exit(1)
for f in pathlib.Path('/proc').glob('[0-9]*/exe'):
 try:x=f.resolve()
 except OSError:continue
 assert not (str(x).startswith(str(r)) and x.name.startswith(('workload_research-','lifecycle_soak-'))),x
PY
do sleep 15; done
source "$ROOT/env.sh"
mkdir -p "$ROOT/analysis-slot-7"
cd "$ROOT/inline-source"
git fetch https://github.com/lambdaclass/spawned.git perf/fede-inline-future > "$ROOT/analysis-slot-7/inline-fetch.log" 2>&1
git reset --hard acd37a3b7cfc01bf8a0b656a30843c14db0859fd >> "$ROOT/analysis-slot-7/inline-fetch.log"
test -z "$(git status --porcelain)"
cargo metadata --locked --offline --all-features --format-version 1 > "$ROOT/analysis-slot-7/metadata.json" 2> "$ROOT/analysis-slot-7/metadata.log"
export CARGO_TARGET_DIR="$ROOT/inline-target" CARGO_BUILD_JOBS=4
printf 'unit\n' > "$ROOT/analysis-slot-7/inline-state"
timeout 600s cargo test --locked -p spawned-rt --features backend-experiments --lib experimental::dispatcher::tests -- --test-threads=1 > "$ROOT/analysis-slot-7/inline-unit.log" 2>&1
printf 'actors\n' > "$ROOT/analysis-slot-7/inline-state"
for policy in native-runnable native-deque; do
 for mode in 0 1; do
  SPAWNED_EXPERIMENT_SCHEDULER="$policy" SPAWNED_EXPERIMENT_WORKERS=2 SPAWNED_EXPERIMENT_BATCH=16 SPAWNED_EXPERIMENT_INLINE_FUTURE=1 SPAWNED_EXPERIMENT_ZERO_SCHEDULE="$mode" SPAWNED_EXPERIMENT_WAKE_PRECHECK="$mode" timeout 300s cargo test --locked -p spawned-concurrency --all-features -- --test-threads=1 --skip badly_behaved_thread_non_blocking > "$ROOT/analysis-slot-7/inline-$policy-$mode-actors.log" 2>&1
 done
done
printf 'workspace\n' > "$ROOT/analysis-slot-7/inline-state"
timeout 600s cargo test --locked --workspace --all-features > "$ROOT/analysis-slot-7/inline-workspace.log" 2>&1
printf 'release\n' > "$ROOT/analysis-slot-7/inline-state"
timeout 600s cargo bench --locked -p spawned-concurrency --features backend-experiments,profiling-experiments --bench workload_research --bench designs --bench lifecycle_soak --no-run > "$ROOT/analysis-slot-7/inline-build.log" 2>&1
git rev-parse HEAD > "$ROOT/analysis-slot-7/inline-checked-source.txt"
printf 'clippy\n' > "$ROOT/analysis-slot-7/inline-state"
export CARGO_TARGET_DIR="$ROOT/inline-clippy"
export RUSTC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustc
export RUSTDOC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustdoc
timeout 600s cargo clippy --locked --workspace --all-targets --all-features -- -D warnings > "$ROOT/analysis-slot-7/inline-clippy.log" 2>&1
printf 'complete\n' > "$ROOT/analysis-slot-7/inline-state"

