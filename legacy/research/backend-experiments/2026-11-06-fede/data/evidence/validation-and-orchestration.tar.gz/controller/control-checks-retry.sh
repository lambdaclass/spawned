#!/usr/bin/env bash
set -euo pipefail
source /tmp/spawned-fede-research-25dGGmPA/env.sh
export CONTROL_ROOT="$RESEARCH_ROOT/controls"
mkdir -p "$CONTROL_ROOT"
trap 'echo failed > "$CONTROL_ROOT/checks-state"' ERR
cd "$CONTROL_ROOT/source"
test -z "$(git status --porcelain)"
git rev-parse HEAD > "$CONTROL_ROOT/checked-source.txt"
export CARGO_TARGET_DIR="$CONTROL_ROOT/target"
echo workspace > "$CONTROL_ROOT/checks-state"
cargo test --locked --workspace --all-features > "$CONTROL_ROOT/workspace.log" 2>&1
echo selected-executors > "$CONTROL_ROOT/checks-state"
for policy in native-steal native-local native-global tokio-pool; do
 SPAWNED_EXPERIMENT_SCHEDULER="$policy" SPAWNED_EXPERIMENT_WORKERS=2 SPAWNED_EXPERIMENT_BATCH=16 cargo test --locked -p spawned-concurrency --all-features -- --test-threads=1 --skip badly_behaved_thread_non_blocking > "$CONTROL_ROOT/integration-$policy.log" 2>&1
done
echo loom > "$CONTROL_ROOT/checks-state"
RUSTFLAGS='--cfg spawned_loom' CARGO_TARGET_DIR="$CONTROL_ROOT/loom-target" cargo test --locked -p spawned-rt --features backend-experiments --lib dispatch_gate::loom_tests -- --test-threads=1 > "$CONTROL_ROOT/loom.log" 2>&1
echo clippy > "$CONTROL_ROOT/checks-state"
RUSTC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustc RUSTDOC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustdoc CARGO_TARGET_DIR="$CONTROL_ROOT/clippy-target" cargo clippy --locked --all-targets --all-features -- -D warnings > "$CONTROL_ROOT/clippy.log" 2>&1
echo build > "$CONTROL_ROOT/checks-state"
cargo bench --locked -p spawned-concurrency --features backend-experiments,profiling-experiments --bench workload_research --bench designs --bench lifecycle_soak --no-run --message-format=json > "$CONTROL_ROOT/artifacts.jsonl" 2> "$CONTROL_ROOT/build.log"
echo complete > "$CONTROL_ROOT/checks-state"
