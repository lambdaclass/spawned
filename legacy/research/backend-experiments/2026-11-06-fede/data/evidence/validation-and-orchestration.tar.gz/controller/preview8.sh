#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
mkdir -p "$ROOT/analysis-slot-8"
while ! python3 -c 'import json,sys; sys.exit(not json.load(open("/tmp/spawned-fede-research-25dGGmPA/amortized-v3/offered-1/metadata.json")).get("finished_utc"))'; do sleep 15; done
test "$(ps -o stat= -p 2282516 | tr -d " ")" = TN
printf "collecting\n" > "$ROOT/analysis-slot-8/state"
python3 "$ROOT/controller/collect_fede_overnight.py" \
 --run V1-smoke="$ROOT/night/smoke-1" \
 --run V1-graphs="$ROOT/night/graphs-1" \
 --run V2-smoke="$ROOT/controls/smoke-1" \
 --run V2-soak-smoke="$ROOT/controls/soak-smoke-1" \
 --run V2-profiles="$ROOT/controls/profiles-1" \
 --run V2-queues="$ROOT/controls/queues-1" \
 --run V2-callers="$ROOT/controls/callers-1" \
 --run V3-smoke="$ROOT/amortized-v3/smoke-1" \
 --run V3-soak-smoke="$ROOT/amortized-v3/soak-smoke-1" \
 --run V3-graphs="$ROOT/amortized-v3/graphs-1" \
 --run V3-profiles="$ROOT/amortized-v3/profiles-1" \
 --run V3-clock="$ROOT/amortized-v3/clock-1" \
 --run V3-offered="$ROOT/amortized-v3/offered-1" \
 --run V4-smoke="$ROOT/runnable-v4/smoke-1" \
 --run V4-scale-smoke="$ROOT/runnable-v4/scale-smoke-1" \
 --run V4-soak-smoke="$ROOT/runnable-v4/soak-smoke-1" \
 --run V4-graphs="$ROOT/runnable-v4/graphs-1" \
 --run V4-profiles="$ROOT/runnable-v4/profiles-1" \
 --run V5-smoke="$ROOT/deque-v5/smoke-1" \
 --run V5-scale-smoke="$ROOT/deque-v5/scale-smoke-1" \
 --run V5-soak-smoke="$ROOT/deque-v5/soak-smoke-1" \
 --run V5-graphs="$ROOT/deque-v5/graphs-1" \
 --run V5-profiles="$ROOT/deque-v5/profiles-1" \
 --run V6-smoke="$ROOT/callback-v6/smoke-1" \
 --run V6-graphs="$ROOT/callback-v6/graphs-1" \
 --run V6-profiles="$ROOT/callback-v6/profiles-1" \
 --run V7-smoke="$ROOT/inline-v7/smoke-1" \
 --run V7-graphs="$ROOT/inline-v7/graphs-1" \
 --run V7-profiles="$ROOT/inline-v7/profiles-1" \
 --run V7-scale-smoke="$ROOT/inline-v7/scale-smoke-1" \
 --run V7-scale-scale="$ROOT/inline-v7/scale-scale-1" \
 --output "$ROOT/analysis-slot-8/preview-data"
"$ROOT/plots/bin/python" "$ROOT/controller/render_fede_overnight.py" --data "$ROOT/analysis-slot-8/preview-data" --output "$ROOT/analysis-slot-8/preview-report"
printf "complete\n" > "$ROOT/analysis-slot-8/state"
kill -CONT 2282516
printf "resumed Root resource parent2282516 after preview complete\n" >> "$ROOT/controller/report-preview-pause.txt"
