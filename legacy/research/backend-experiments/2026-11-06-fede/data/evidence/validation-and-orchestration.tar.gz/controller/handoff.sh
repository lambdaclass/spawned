#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
while test "$(cat "$ROOT/analysis-slot-6/callback-state" 2>/dev/null || true)" != complete; do sleep 10; done
python3 - "$ROOT" <<'PY'
import pathlib,json,sys,os,signal
r=pathlib.Path(sys.argv[1])
assert json.loads((r/'runnable-v4/graphs-1/metadata.json').read_text()).get('finished_utc')
for pid,name in [(1087975,'root-v3-run.sh'),(1748742,'early-run.sh')]:
 cmd=pathlib.Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\0',b' ').decode().strip()
 assert cmd==f'bash {r}/controller/{name}',cmd
 assert '\nState:\tT' in pathlib.Path(f'/proc/{pid}/status').read_text()
for f in pathlib.Path('/proc').glob('[0-9]*/exe'):
 try:x=f.resolve()
 except OSError:continue
 assert not (str(x).startswith(str(r)) and x.name.startswith(('workload_research-','lifecycle_soak-'))),x
(r/'amortized-v3/run-state').write_text('waiting-early-rest\n')
(r/'controller/early-state').write_text('handoff\n')
for pid in [1087975,1748742]:os.kill(pid,signal.SIGKILL)
# Replace only our waiting V4 tail to pass the predeclared common 300s duration.
for path in pathlib.Path('/proc').glob('[0-9]*/cmdline'):
 try:cmd=path.read_bytes().replace(b'\0',b' ').decode().strip()
 except OSError:continue
 if cmd==f'bash {r}/controller/runnable-tail.sh':os.kill(int(path.parent.name),signal.SIGKILL)
(r/'controller/handoff-300s.txt').write_text('V4graphs680complete10:00:23UTC. Callbackgatescomplete. Pausedparents1087975/1748742retiredatcompletedphaseboundary,noactivebenchmark. Newroot-rest waits early-rest; all14resourcecases300seconds,chosenBEFOREanylong-soakoutcome,tocovercandidatefamiliesandreviewwithin10h. Sourcecheckoutshashesunchanged. DoNOTresumeoldPIDs. Newouterwrappersarchived.\n')
PY
nohup nice -n 10 taskset -c 2,3,4,5 bash "$ROOT/controller/root-rest.sh" > "$ROOT/controller/root-rest.log" 2>&1 < /dev/null &
nohup nice -n 10 taskset -c 2,3,4,5 bash "$ROOT/controller/runnable-tail300.sh" > "$ROOT/controller/runnable-tail300.log" 2>&1 < /dev/null &
nohup nice -n 10 taskset -c 2,3,4,5 bash "$ROOT/controller/early-rest.sh" > "$ROOT/controller/early-rest.log" 2>&1 < /dev/null &
printf 'handoff-complete\n' > "$ROOT/controller/handoff-state"

