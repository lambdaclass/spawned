#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
mkdir -p "$ROOT/fairness-v8"
printf 'waiting-v4-tail-and-gates\n' > "$ROOT/fairness-v8/run-state"
while test "$(cat "$ROOT/runnable-v4/run-state")" != complete-with-scale-deferred; do
 if test "$(date +%s)" -ge 1793971800; then printf 'not-launched-budget\n' > "$ROOT/fairness-v8/run-state"; exit 0; fi
 if test "$(cat "$ROOT/runnable-v4/run-state")" = failed; then printf 'blocked-earlier-failure\n' > "$ROOT/fairness-v8/run-state"; exit 1; fi
 sleep 15
done
test "$(cat "$ROOT/analysis-slot-9/fairness-state")" = complete
if test "$(date +%s)" -ge 1793971800; then printf 'not-launched-budget\n' > "$ROOT/fairness-v8/run-state"; exit 0; fi
source "$ROOT/env.sh"
cd "$ROOT/fairness-source"
export CARGO_TARGET_DIR="$ROOT/fairness-target"
test "$(git rev-parse HEAD)" = e633e590a7cd286b1b15e47153995b6787c5d396
test -z "$(git status --porcelain)"
trap 'printf "failed\n" > "$ROOT/fairness-v8/run-state"' ERR
for stage in graph-smoke scale-smoke smoke soak-smoke graphs profiles scale offered soaks; do
 printf '%s\n' "$stage" > "$ROOT/fairness-v8/run-state"
 cpus=2,3,4,5; if test "$stage" = scale || test "$stage" = scale-smoke; then cpus=2,3,4,5,6,7,8,9; fi
 taskset -c "$cpus" python3 "$ROOT/controller/frontier8.py" --stage "$stage" --stop-at 1793974800 --output "$ROOT/fairness-v8/$stage-1" > "$ROOT/fairness-v8/$stage.log" 2>&1
 python3 - "$ROOT/fairness-v8/$stage-1" "$stage" <<'PY'
import csv,json,pathlib,sys
p=pathlib.Path(sys.argv[1]);stage=sys.argv[2]
m=json.loads((p/'metadata.json').read_text());n=len(list(csv.DictReader((p/'raw.csv').open())))
assert m.get('finished_utc') and not m.get('stopped_at_deadline'),(stage,'truncated')
assert n=={'graph-smoke':24,'scale-smoke':24,'smoke':44,'soak-smoke':5,'graphs':120,'profiles':12,'scale':72,'offered':176,'soaks':5}[stage]
PY
done
printf 'complete\n' > "$ROOT/fairness-v8/run-state"
