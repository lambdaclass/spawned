#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
while ! python3 - "$ROOT" <<'PY'
import json,sys,pathlib
r=pathlib.Path(sys.argv[1]);p=r/'amortized-v3/graphs-1/metadata.json'
s=pathlib.Path('/proc/1087975/status').read_text()
assert '\nState:\tT' in s, 'parent must be paused'
if not json.loads(p.read_text()).get('finished_utc'):sys.exit(1)
for f in pathlib.Path('/proc').glob('[0-9]*/exe'):
 try:x=f.resolve()
 except OSError:continue
 assert not (str(x).startswith(str(r)) and x.name.startswith(('workload_research-','lifecycle_soak-'))), x
PY
do sleep 15; done
source "$ROOT/env.sh"
cd "$ROOT/runnable-source"
mkdir -p "$ROOT/analysis-slot-4"
printf 'resolving\n' > "$ROOT/analysis-slot-4/state"
if ! timeout 180s cargo metadata --offline --format-version 1 --no-deps > "$ROOT/analysis-slot-4/metadata.json" 2> "$ROOT/analysis-slot-4/resolve-offline.log"; then
 timeout 180s cargo metadata --format-version 1 --no-deps > "$ROOT/analysis-slot-4/metadata.json" 2> "$ROOT/analysis-slot-4/resolve-online.log"
fi
printf 'lock-ready\n' > "$ROOT/analysis-slot-4/state"
