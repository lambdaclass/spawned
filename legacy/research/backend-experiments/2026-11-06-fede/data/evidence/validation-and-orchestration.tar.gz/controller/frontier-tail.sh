#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
mkdir -p "$ROOT/frontier-v7"
printf 'waiting-existing-campaigns\n' > "$ROOT/frontier-v7/run-state"
while test "$(cat "$ROOT/deque-v5/run-state")" != complete; do
 if test "$(date +%s)" -ge 1793972100; then printf 'not-launched-budget\n' > "$ROOT/frontier-v7/run-state"; exit 0; fi
 if test "$(cat "$ROOT/deque-v5/run-state")" = failed; then printf 'blocked-earlier-failure\n' > "$ROOT/frontier-v7/run-state"; exit 1; fi
 sleep 15
done
if test "$(date +%s)" -ge 1793972100; then printf 'not-launched-budget\n' > "$ROOT/frontier-v7/run-state"; exit 0; fi
source "$ROOT/env.sh"
cd "$ROOT/inline-source"
export CARGO_TARGET_DIR="$ROOT/inline-target"
test "$(git rev-parse HEAD)" = acd37a3b7cfc01bf8a0b656a30843c14db0859fd
test -z "$(git status --porcelain)"
trap 'printf "failed\n" > "$ROOT/frontier-v7/run-state"' ERR
for stage in smoke soak-smoke offered soaks; do
 printf '%s\n' "$stage" > "$ROOT/frontier-v7/run-state"
 taskset -c 2,3,4,5 python3 "$ROOT/controller/frontier.py" --stage "$stage" --stop-at 1793974800 --output "$ROOT/frontier-v7/$stage-1" > "$ROOT/frontier-v7/$stage.log" 2>&1
 python3 - "$ROOT/frontier-v7/$stage-1" "$stage" <<'PY'
import csv,json,pathlib,sys
p=pathlib.Path(sys.argv[1]);stage=sys.argv[2]
m=json.loads((p/'metadata.json').read_text());n=len(list(csv.DictReader((p/'raw.csv').open())))
assert m.get('finished_utc') and not m.get('stopped_at_deadline'), (stage,'truncated')
assert n=={'smoke':44,'soak-smoke':5,'offered':176,'soaks':5}[stage]
PY
done
printf 'complete\n' > "$ROOT/frontier-v7/run-state"
