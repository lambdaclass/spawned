#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
python3 "$ROOT/controller/collect_fede_overnight.py" \
 --run V1-smoke="$ROOT/night/smoke-1" --run V1-graphs="$ROOT/night/graphs-1" \
 --run V2-smoke="$ROOT/controls/smoke-1" --run V2-soak-smoke="$ROOT/controls/soak-smoke-1" \
 --run V2-profiles="$ROOT/controls/profiles-1" --run V2-queues="$ROOT/controls/queues-1" --run V2-callers="$ROOT/controls/callers-1" \
 --run V3-smoke="$ROOT/amortized-v3/smoke-1" --run V3-soak-smoke="$ROOT/amortized-v3/soak-smoke-1" --run V3-graphs="$ROOT/amortized-v3/graphs-1" \
 --output "$ROOT/analysis-slot-4/preview-data"
"$ROOT/plots/bin/python" "$ROOT/controller/render_fede_overnight.py" --data "$ROOT/analysis-slot-4/preview-data" --output "$ROOT/analysis-slot-4/preview-report"
printf 'complete\n' > "$ROOT/analysis-slot-4/preview-state"

