#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
while true; do
 state=$(cat "$ROOT/amortized-v3/run-state")
 if test "$state" = complete && test "$(cat "$ROOT/controller/early-state")" = complete; then break; fi
 if test "$state" = failed; then exit 1; fi
 if test "$(date +%s)" -ge 1793975400; then printf 'deadline-before-tail\n' > "$ROOT/runnable-v4/run-state"; exit 0; fi
 sleep 15
done
source "$ROOT/env.sh"
cd "$ROOT/runnable-source"
export CARGO_TARGET_DIR="$ROOT/runnable-target"
test "$(git rev-parse HEAD)" = 09dd194b832bc6136453f40a17e1a6f718a08a4f
test -z "$(git status --porcelain)"
trap 'printf "failed\n" > "$ROOT/runnable-v4/run-state"' ERR
for stage in scale offered; do
 printf '%s\n' "$stage" > "$ROOT/runnable-v4/run-state"
 cpus=2,3,4,5; if test "$stage" = scale; then cpus=2,3,4,5,6,7,8,9; fi
 taskset -c "$cpus" python3 benchmarks/fede_runnable.py --stage "$stage" --stop-at 1793975400 --output "$ROOT/runnable-v4/$stage-1" > "$ROOT/runnable-v4/$stage.log" 2>&1
done
printf 'soaks\n' > "$ROOT/runnable-v4/run-state"
taskset -c 2,3,4,5 python3 benchmarks/fede_soak.py --runnable-only --seconds 600 --stop-at 1793975400 --output "$ROOT/runnable-v4/soaks-1" > "$ROOT/runnable-v4/soaks.log" 2>&1
python3 - "$ROOT/runnable-v4" <<'PY'
import json,pathlib,sys,csv
r=pathlib.Path(sys.argv[1]);ok=True
for stage,expected in [('graphs',680),('profiles',20),('scale',480),('offered',252),('soaks',2)]:
 p=r/(stage+'-1');m=json.loads((p/'metadata.json').read_text());n=len(list(csv.DictReader((p/'raw.csv').open()))) if (p/'raw.csv').exists() else 0
 ok &= bool(m.get('finished_utc')) and not m.get('stopped_at_deadline') and n==expected
(r/'run-state').write_text('complete\n' if ok else 'deadline-partial\n')
PY

