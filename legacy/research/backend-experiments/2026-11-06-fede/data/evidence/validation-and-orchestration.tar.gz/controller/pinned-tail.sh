#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
mkdir -p "$ROOT/pinned-v9"
trap 'printf "failed\n" > "$ROOT/pinned-v9/run-state"' ERR
while true; do
 state=$(cat "$ROOT/analysis-slot-11/pinned-state")
 test "$state" != failed
 test "$state" != complete || break
 sleep 5
done
source "$ROOT/env.sh"
export CARGO_TARGET_DIR="$ROOT/fairness-target"
cd "$ROOT/pinned-source"
STOP=$(date -u -d '2026-11-06 14:15:00' +%s)
for stage in smoke pipeline; do
 printf '%s\n' "$stage" > "$ROOT/pinned-v9/run-state"
 python3 "$ROOT/controller/pinned9.py" --stage "$stage" --output "$ROOT/pinned-v9/$stage-1" --stop-at "$STOP"
done
printf 'complete\n' > "$ROOT/pinned-v9/run-state"
