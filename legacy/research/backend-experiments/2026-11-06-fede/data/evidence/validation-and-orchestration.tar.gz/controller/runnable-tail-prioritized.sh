#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
while test "$(cat "$ROOT/amortized-v3/run-state")" != complete; do
 if test "$(date +%s)" -ge 1793975400; then printf 'deadline-before-tail\n' > "$ROOT/runnable-v4/run-state"; exit 0; fi
 if test "$(cat "$ROOT/amortized-v3/run-state")" = failed; then exit 1; fi
 sleep 15
done
source "$ROOT/env.sh"
cd "$ROOT/runnable-source"
export CARGO_TARGET_DIR="$ROOT/runnable-target"
test "$(git rev-parse HEAD)" = 09dd194b832bc6136453f40a17e1a6f718a08a4f
test -z "$(git status --porcelain)"
trap 'printf "failed\n" > "$ROOT/runnable-v4/run-state"' ERR
printf 'offered\n' > "$ROOT/runnable-v4/run-state"
taskset -c 2,3,4,5 python3 benchmarks/fede_runnable.py --stage offered --stop-at 1793975400 --output "$ROOT/runnable-v4/offered-1" > "$ROOT/runnable-v4/offered.log" 2>&1
printf 'soaks\n' > "$ROOT/runnable-v4/run-state"
taskset -c 2,3,4,5 python3 benchmarks/fede_soak.py --runnable-only --seconds 300 --stop-at 1793975400 --output "$ROOT/runnable-v4/soaks-1" > "$ROOT/runnable-v4/soaks.log" 2>&1
python3 - "$ROOT/runnable-v4" <<'PY'
import pathlib,csv,json,sys
r=pathlib.Path(sys.argv[1]);ok=True
for stage,count in [('graphs-1',680),('profiles-1',20),('offered-1',252),('soaks-1',2)]:
 p=r/stage;m=json.loads((p/'metadata.json').read_text());n=len(list(csv.DictReader((p/'raw.csv').open())))
 ok &= bool(m.get('finished_utc')) and not m.get('stopped_at_deadline') and n==count
(r/'run-state').write_text('complete-with-scale-deferred\n' if ok else 'deadline-partial\n')
PY
