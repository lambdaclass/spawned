#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
mkdir -p "$ROOT/analysis-slot-10"
trap 'printf "failed\n" > "$ROOT/analysis-slot-10/fairness-state"' ERR
while ! python3 -c 'import json,sys; sys.exit(not json.load(open("/tmp/spawned-fede-research-25dGGmPA/amortized-v3/soaks-3/metadata.json")).get("finished_utc"))'; do sleep 15; done
test "$(ps -o stat= -p 2843287 | tr -d " ")" = TN
python3 - "$ROOT" <<'PY'
import pathlib,sys
r=pathlib.Path(sys.argv[1])
for f in pathlib.Path('/proc').glob('[0-9]*/exe'):
 try:x=f.resolve()
 except OSError:continue
 assert not (str(x).startswith(str(r)) and x.name.startswith(('workload_research-','lifecycle_soak-'))),x
PY
source "$ROOT/env.sh"
cd "$ROOT/fairness-source"
git fetch https://github.com/lambdaclass/spawned.git perf/fede-owner-deque-review > "$ROOT/analysis-slot-10/fairness-fetch.log" 2>&1
git checkout --detach 1dcfea1a64a32b8a6717284a6734f7368240ca5b >> "$ROOT/analysis-slot-10/fairness-fetch.log" 2>&1
test -z "$(git status --porcelain)"
export CARGO_TARGET_DIR="$ROOT/fairness-target" CARGO_BUILD_JOBS=4
printf 'unit\n' > "$ROOT/analysis-slot-10/fairness-state"
timeout 600s cargo test --locked -p spawned-rt --features backend-experiments --lib -- --test-threads=1 > "$ROOT/analysis-slot-10/fairness-unit.log" 2>&1
printf 'actors\n' > "$ROOT/analysis-slot-10/fairness-state"
for mode in 0 1; do
 SPAWNED_EXPERIMENT_SCHEDULER=native-deque SPAWNED_EXPERIMENT_WORKERS=4 SPAWNED_EXPERIMENT_BATCH=16 SPAWNED_EXPERIMENT_ZERO_SCHEDULE="$mode" SPAWNED_EXPERIMENT_WAKE_PRECHECK="$mode" timeout 300s cargo test --locked -p spawned-concurrency --all-features -- --test-threads=1 --skip badly_behaved_thread_non_blocking > "$ROOT/analysis-slot-10/fairness-deque-mode$mode-actors.log" 2>&1
done
printf 'workspace\n' > "$ROOT/analysis-slot-10/fairness-state"
timeout 600s cargo test --locked --workspace --all-features > "$ROOT/analysis-slot-10/fairness-workspace.log" 2>&1
printf 'release\n' > "$ROOT/analysis-slot-10/fairness-state"
timeout 600s cargo bench --locked -p spawned-concurrency --features backend-experiments,profiling-experiments --bench workload_research --bench designs --bench lifecycle_soak --no-run > "$ROOT/analysis-slot-10/fairness-build.log" 2>&1
git rev-parse HEAD > "$ROOT/analysis-slot-10/fairness-checked-source.txt"
printf 'clippy\n' > "$ROOT/analysis-slot-10/fairness-state"
export CARGO_TARGET_DIR="$ROOT/fairness-clippy"
export RUSTC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustc
export RUSTDOC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustdoc
timeout 600s cargo clippy --locked --workspace --all-targets --all-features -- -D warnings > "$ROOT/analysis-slot-10/fairness-clippy.log" 2>&1
printf 'complete\n' > "$ROOT/analysis-slot-10/fairness-state"
kill -CONT 2843287
printf 'Resumed only Root shell2843287 after final V8 source gates\n' >> "$ROOT/controller/final-v8-gate-gap.txt"
