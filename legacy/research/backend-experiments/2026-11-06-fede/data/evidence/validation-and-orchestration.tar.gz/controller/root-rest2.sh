#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
source "$ROOT/env.sh"
cd "$ROOT/amortized-source"
export CARGO_TARGET_DIR="$ROOT/amortized-target"
test "$(git rev-parse HEAD)" = 097ae02f6d05e383b303594bfe9fbfbfc9141666
test -z "$(git status --porcelain)"
trap 'printf "failed\n" > "$ROOT/amortized-v3/run-state"' ERR
printf 'resource-rerun\n' > "$ROOT/amortized-v3/run-state"
taskset -c 2,3,4,5 python3 benchmarks/fede_soak.py --seconds 300 --stop-at 1793975400 --output "$ROOT/amortized-v3/soaks-2" > "$ROOT/amortized-v3/soaks-2.log" 2>&1
python3 - "$ROOT/amortized-v3" <<'PY'
import json,pathlib,sys,csv
r=pathlib.Path(sys.argv[1]);ok=True
for stage,count in [('graphs-1',520),('profiles-1',24),('clock-1',340),('offered-1',432),('soaks-2',10)]:
 p=r/stage;m=json.loads((p/'metadata.json').read_text());n=len(list(csv.DictReader((p/'raw.csv').open()))) if (p/'raw.csv').exists() else 0
 ok &= bool(m.get('finished_utc')) and not m.get('stopped_at_deadline') and n==count
(r/'run-state').write_text('complete\n' if ok else 'deadline-partial\n')
PY
