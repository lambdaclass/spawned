#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
while ! python3 - "$ROOT" <<'PY'
import json,sys,pathlib
r=pathlib.Path(sys.argv[1])
assert '\nState:\tT' in pathlib.Path('/proc/1087975/status').read_text()
if not json.loads((r/'amortized-v3/clock-1/metadata.json').read_text()).get('finished_utc'):sys.exit(1)
PY
do sleep 15; done
mkdir -p "$ROOT/analysis-slot-5"
if test -d "$ROOT/runnable-v4"; then mv "$ROOT/runnable-v4" "$ROOT/runnable-v4-preflight-9a"; fi
mkdir "$ROOT/runnable-v4"
bash "$ROOT/controller/runnable-final-checks.sh"

