#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
source "$ROOT/env.sh"
export CARGO_TARGET_DIR="$ROOT/runnable-target"
cd "$ROOT/runnable-source"
test "$(git rev-parse HEAD)" = 9a6971155aeb8efa83b484d7459e6d7488c84aea
test -z "$(git status --porcelain)"
test -f "$ROOT/runnable-v4/MEASUREMENT-APPROVED"
printf 'waiting-v3\n' > "$ROOT/runnable-v4/run-state"
while true; do
 state=$(cat "$ROOT/amortized-v3/run-state")
 if test "$state" = complete; then break; fi
 if test "$state" = failed; then printf 'blocked-v3-failure\n' > "$ROOT/runnable-v4/run-state"; exit 1; fi
 if test "$(date +%s)" -ge 1793975400; then printf 'deadline-before-start\n' > "$ROOT/runnable-v4/run-state"; exit 0; fi
 sleep 15
done
trap 'printf "failed\n" > "$ROOT/runnable-v4/run-state"' ERR
for stage in graphs profiles scale offered; do
 printf '%s\n' "$stage" > "$ROOT/runnable-v4/run-state"
 cpus=2,3,4,5
 if test "$stage" = scale; then cpus=2,3,4,5,6,7,8,9; fi
 taskset -c "$cpus" python3 benchmarks/fede_runnable.py --stage "$stage" --stop-at 1793975400 --output "$ROOT/runnable-v4/$stage-1" > "$ROOT/runnable-v4/$stage.log" 2>&1
done
printf 'soaks\n' > "$ROOT/runnable-v4/run-state"
taskset -c 2,3,4,5 python3 benchmarks/fede_soak.py --runnable-only --seconds 600 --stop-at 1793975400 --output "$ROOT/runnable-v4/soaks-1" > "$ROOT/runnable-v4/soaks.log" 2>&1
printf 'complete\n' > "$ROOT/runnable-v4/run-state"

