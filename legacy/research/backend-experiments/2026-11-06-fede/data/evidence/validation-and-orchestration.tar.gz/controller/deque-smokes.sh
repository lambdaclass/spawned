#!/usr/bin/env bash
set -euo pipefail
ROOT=/tmp/spawned-fede-research-25dGGmPA
source "$ROOT/env.sh"
cd "$ROOT/deque-source"
test "$(git rev-parse HEAD)" = 329006e8c02e7c4b2711d035ac2f942454c2e723
test -z "$(git status --porcelain)"
test "$(cat "$ROOT/analysis-slot-5/deque-state")" = complete
export CARGO_TARGET_DIR="$ROOT/deque-target"
mkdir -p "$ROOT/deque-v5"
printf 'smoke\n' > "$ROOT/deque-v5/run-state"
taskset -c 2,3,4,5 python3 benchmarks/fede_deque.py --stage smoke --stop-at 1793975400 --output "$ROOT/deque-v5/smoke-1" > "$ROOT/deque-v5/smoke.log" 2>&1
printf 'scale-smoke\n' > "$ROOT/deque-v5/run-state"
taskset -c 2,3,4,5,6,7,8,9 python3 benchmarks/fede_deque.py --stage scale-smoke --stop-at 1793975400 --output "$ROOT/deque-v5/scale-smoke-1" > "$ROOT/deque-v5/scale-smoke.log" 2>&1
printf 'soak-smoke\n' > "$ROOT/deque-v5/run-state"
taskset -c 2,3,4,5 python3 benchmarks/fede_soak.py --deque-only --smoke --seconds 3 --stop-at 1793975400 --output "$ROOT/deque-v5/soak-smoke-1" > "$ROOT/deque-v5/soak-smoke.log" 2>&1
printf 'smokes-complete-waiting-v3\n' > "$ROOT/deque-v5/run-state"
printf '329006e8c02e7c4b2711d035ac2f942454c2e723 gates + 112/28/2 smoke complete\n' > "$ROOT/deque-v5/MEASUREMENT-APPROVED"
