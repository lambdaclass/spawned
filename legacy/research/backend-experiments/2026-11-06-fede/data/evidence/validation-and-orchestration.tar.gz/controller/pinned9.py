#!/usr/bin/env python3
"""Predeclared pinned-pipeline comparison. Linux only; private experimental profiles."""
import argparse
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import subprocess
import sys
import time

SOURCE=Path('/tmp/spawned-fede-research-25dGGmPA/pinned-source')
REVISION='a8471f74b2b2d8c6550690d27679216a7341c774'
sys.path.insert(0,str(SOURCE/'benchmarks'))
from fede_research import capture, process, write_rows
HASH=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--stage',choices=['smoke','pipeline'],required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--stop-at',type=float,required=True)
    a=p.parse_args()
    assert __debug__ and capture('git','rev-parse','HEAD')==REVISION
    assert not capture('git','status','--porcelain')
    assert os.nice(0)==10 and os.sched_getaffinity(0)==set(range(2,10))
    out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
    for name in ['logs','series']:(out/name).mkdir()
    smoke=a.stage=='smoke';repeats=1 if smoke else 3
    jobs=[(variant,n,g,r) for variant in ['async','pinned-park','pinned-spin']
          for n in [1,2,4,8] for g in [1,16] for r in range(repeats)]
    random.Random(9181 if smoke else 9182).shuffle(jobs)
    meta=dict(started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),revision=REVISION,
              dirty=False,rustc=capture('rustc','--version'),cargo=capture('cargo','--version'),
              cpu=capture('lscpu'),load_before=Path('/proc/loadavg').read_text(),
              actor_cpus='per-case first N CPUs from 2,3,4,5,6,7,8,9',driver_cpus='10,11,12,13',
              nice=os.nice(0),controller_sha256=HASH,planned_samples=len(jobs),schedule=[],
              purpose='Same 800-step LCG per root; N sequential stages across N actor cores, either 1 or16 actors per core. 256 producers/four fixed driver threads. Fresh CPP each case. Sharded profiles pin each worker before startup, one current-thread Tokio runtime per core; spin is persistent yielding owner, not Flux ring transport. Baseline N Tokio workers share same actor CPU mask, not individual pinning. Actor placement audited before warmup; one end-to-end reply, ordinary owned Work messages/boxed addressed mailboxes. Independent E2E streaming fixture, not pooled with earlier recursive eight-hop RPC graphs. N=8 spans asymmetric L3 domains; compute is fixed but message/hop count changes with N. Process idle/active CPU includes all runtime/driver threads; no actor-only or power estimate. 1s idle window and1Mroots chosen before scoring. No support promotion.')
    build=subprocess.run(['cargo','bench','--locked','-p','spawned-concurrency','--features','backend-experiments','--bench','pinned_pipeline','--no-run','--message-format=json'],cwd=SOURCE,capture_output=True,text=True)
    (out/'build.log').write_text(build.stderr);build.check_returncode()
    artifacts=[json.loads(s) for s in build.stdout.splitlines()]
    executable=next(x['executable'] for x in artifacts if x.get('reason')=='compiler-artifact' and x['target']['name']=='pinned_pipeline' and x.get('executable'))
    meta['binary_sha256']=hashlib.sha256(Path(executable).read_bytes()).hexdigest()
    records=[]
    def save():
        (out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
        if records:write_rows(out/'raw.csv',records)
    save()
    for variant,n,g,repeat in jobs:
        if time.time()+120>=a.stop_at:meta['stopped_at_deadline']=True;break
        cores=','.join(map(str,range(2,2+n)))
        exp={} if variant=='async' else dict(SPAWNED_EXPERIMENT_SCHEDULER='sharded',SPAWNED_EXPERIMENT_WORKERS=n,SPAWNED_EXPERIMENT_BATCH=16,SPAWNED_EXPERIMENT_SLICE_US=50,SPAWNED_EXPERIMENT_PIN_CORES=cores,SPAWNED_EXPERIMENT_IDLE_SPIN=int(variant=='pinned-spin'))
        env={k:v for k,v in os.environ.items() if not k.startswith(('SPAWNED_EXPERIMENT_','SPAWNED_PROFILE_')) and k!='TOKIO_WORKER_THREADS'}
        env.update({k:str(v) for k,v in exp.items()});env['LC_ALL']='C'
        stem=f'{len(records):03d}-{variant}-n{n}-g{g}-r{repeat}'
        cfg=dict(workers=n,groups=g,messages=4096 if smoke else 1_048_576,producers=256,
                 **{'idle-ms':1000,'actor-cpus':cores,'driver-cpus':'10,11,12,13','audit':str(out/'series'/f'{stem}.csv')})
        meta['schedule'].append(dict(variant=variant,workers=n,repeat=repeat,config=cfg,experiment=exp));save()
        start=time.monotonic()
        status,stdout,stderr=process(['taskset','-c',cores,'/usr/bin/time','-v',executable]+[f'--{k}={v}' for k,v in cfg.items()],env,out/'logs'/stem,120)
        row=dict(phase='pinned-smoke' if smoke else 'pinned-pipeline',variant=variant,workers=n,
                 actor_workers=n,total_runtime_workers=n,repeat=repeat,status=status,stem=stem,
                 wall_s=time.monotonic()-start,config_json=json.dumps(dict(cfg,actors=n*g),sort_keys=True),experiment_json=json.dumps(exp,sort_keys=True))
        if status=='ok':
            parsed=list(csv.DictReader(stdout.splitlines()));assert len(parsed)==1 and None not in parsed[0] and all(v is not None for v in parsed[0].values())
            row.update(parsed[0]);assert int(row['messages'])==int(row['succeeded']) and int(row['timeouts'])==0
            assert int(row['started'])==int(row['stopped'])==int(row['dropped'])==n*g
            audit=list(csv.DictReader(Path(cfg['audit']).open()));assert len(audit)==n*g
            if variant!='async':
                assert all(x['thread']==f'spawned-shard-{i%n}' and x['allowed_cpus']==str(2+i%n) for i,x in enumerate(audit))
        records.append(row);save();print(f'{len(records)}/{len(jobs)} {stem}: {status}',flush=True)
        if status!='ok':raise RuntimeError('Preserve failed case and investigate before any further scoring')
    meta['finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());save()

if __name__=='__main__':main()
