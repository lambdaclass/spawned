#!/usr/bin/env bash
set -euo pipefail
source /tmp/spawned-fede-research-25dGGmPA/env.sh
SLOT="$RESEARCH_ROOT/analysis-slot-3"
mkdir -p "$SLOT"
trap 'echo failed > "$SLOT/state"' ERR
echo waiting-callers > "$SLOT/state"
until python3 -c 'import json,sys;sys.exit(not json.load(open("/tmp/spawned-fede-research-25dGGmPA/controls/callers-1/metadata.json")).get("finished_utc"))'; do sleep 10; done
grep -q '^State:.*T' /proc/450759/status
if pgrep -f '^/tmp/spawned-fede-research-25dGGmPA/controls/target/release/deps/workload_research-'; then exit 1; fi
echo stop-proof > "$SLOT/state"
git clone --shared --no-checkout "$RESEARCH_ROOT/source" "$RESEARCH_ROOT/stop-proof" > "$SLOT/stop-checkout.log" 2>&1
git -C "$RESEARCH_ROOT/stop-proof" fetch https://github.com/lambdaclass/spawned.git fix/idle-stop-cancel >> "$SLOT/stop-checkout.log" 2>&1
git -C "$RESEARCH_ROOT/stop-proof" checkout --detach FETCH_HEAD >> "$SLOT/stop-checkout.log" 2>&1
set +e
(cd "$RESEARCH_ROOT/stop-proof"; CARGO_TARGET_DIR="$RESEARCH_ROOT/stop-target" cargo test --locked -p spawned-concurrency --lib idle_stop_regression -- --test-threads=1) > "$SLOT/idle-stop-before.log" 2>&1
echo "$?" > "$SLOT/idle-stop-before.status"
set -e
echo root-checkout > "$SLOT/state"
git clone --shared --no-checkout "$RESEARCH_ROOT/controls/source" "$RESEARCH_ROOT/amortized-source" > "$SLOT/root-checkout.log" 2>&1
git -C "$RESEARCH_ROOT/amortized-source" fetch https://github.com/lambdaclass/spawned.git perf/fede-amortized-dispatch >> "$SLOT/root-checkout.log" 2>&1
git -C "$RESEARCH_ROOT/amortized-source" checkout --detach FETCH_HEAD >> "$SLOT/root-checkout.log" 2>&1
cd "$RESEARCH_ROOT/amortized-source"
export CARGO_TARGET_DIR="$RESEARCH_ROOT/amortized-target"
echo root-unit > "$SLOT/state"
cargo test --locked -p spawned-rt --features backend-experiments --lib dispatcher::tests -- --test-threads=1 > "$SLOT/root-unit.log" 2>&1
echo root-actors > "$SLOT/state"
SPAWNED_EXPERIMENT_SCHEDULER=native-root SPAWNED_EXPERIMENT_WORKERS=2 SPAWNED_EXPERIMENT_BATCH=16 cargo test --locked -p spawned-concurrency --all-features -- --test-threads=1 --skip badly_behaved_thread_non_blocking > "$SLOT/root-actors.log" 2>&1
echo root-clippy > "$SLOT/state"
RUSTC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustc RUSTDOC=/nix/store/xvp6nfxayb07si2jaggqwvx3iykw89g2-rustc-1.98.1/bin/rustdoc CARGO_TARGET_DIR="$RESEARCH_ROOT/amortized-clippy" cargo clippy --locked --all-targets --all-features -- -D warnings > "$SLOT/root-clippy.log" 2>&1
echo complete > "$SLOT/state"
